package com.example.projecttwojenniferwells

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApp()
        }
    }
}

// Simulated in-memory "database"
object InMemoryDatabase {
    private var items = mutableStateListOf(
        DataItem(1, "Item 1"),
        DataItem(2, "Item 2")
    )

    fun getItems() = items

    fun addItem(title: String) {
        val newItem = DataItem(items.size + 1, title)
        items.add(newItem)
    }

    fun removeItem(id: Int) {
        items.removeIf { it.id == id }
    }
}

data class DataItem(val id: Int, var title: String)

@Composable
fun MyApp() {
    var currentScreen by remember { mutableStateOf("login") }
    var permissionGranted by remember { mutableStateOf(false) }
    var infoMessage by remember { mutableStateOf("Please log in or sign up.") }

    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        permissionGranted = isGranted
        if (isGranted) {
            infoMessage = "SMS permission granted. You will now receive notifications."
        } else {
            infoMessage = "SMS permission denied. Notifications will not be sent via SMS."
            currentScreen = "dataDisplay" // Adjust screen state as needed, but after the if-else block
        }
    }

    when (currentScreen) {
        "login" -> LoginScreen(
            onLoginSuccess = { currentScreen = "permissions" },
            onCreateAccount = { /* */ }
        )
        "dataDisplay" -> DataDisplayScreen()
        "permissions" -> PermissionsScreen(
            onRequestPermissions = { requestPermissionLauncher.launch(Manifest.permission.SEND_SMS) },
            permissionGranted = permissionGranted,
            infoMessage = infoMessage,
            onContinue = { currentScreen = "dataDisplay" }
        )
    }
}

@Composable
fun LoginScreen(onLoginSuccess: () -> Unit, onCreateAccount: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        var username by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }

        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") }
        )
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onLoginSuccess) {
            Text("Login")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = onCreateAccount) {
            Text("Sign Up")
        }
    }
}

@Composable
fun DataDisplayScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Data Display Screen - ")
    }
}

@Composable
fun PermissionsScreen(onRequestPermissions: () -> Unit, permissionGranted: Boolean, infoMessage: String, onContinue: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = onRequestPermissions) {
            Text("Request SMS Permissions")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(infoMessage)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onContinue) {
            Text("Continue")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyApp()
}